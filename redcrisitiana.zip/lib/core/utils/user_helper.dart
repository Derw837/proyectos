import 'package:supabase_flutter/supabase_flutter.dart';

class UserHelper {
  static final _client = Supabase.instance.client;

  static Future<Map<String, dynamic>?> getProfile() async {
    final user = _client.auth.currentUser;
    if (user == null) return null;

    final existing = await _client
        .from('profiles')
        .select()
        .eq('id', user.id)
        .maybeSingle();

    return existing;
  }

  static Future<Map<String, dynamic>?> createUserProfileWithUserId({
    required String userId,
    required String fullName,
    required String country,
    required String city,
    required String sector,
  }) async {
    await _client.from('profiles').upsert({
      'id': userId,
      'full_name': fullName,
      'role': 'user',
      'country': country,
      'city': city,
      'sector': sector,
      'approval_status': 'approved',
    });

    final profile = await _client
        .from('profiles')
        .select()
        .eq('id', userId)
        .maybeSingle();

    return profile;
  }

  static Future<Map<String, dynamic>?> createChurchProfilePlaceholderWithUserId({
    required String userId,
    required String fullName,
    required String country,
    required String city,
    required String sector,
  }) async {
    await _client.from('profiles').upsert({
      'id': userId,
      'full_name': fullName,
      'role': 'church',
      'country': country,
      'city': city,
      'sector': sector,
      'approval_status': 'pending',
    });

    final profile = await _client
        .from('profiles')
        .select()
        .eq('id', userId)
        .maybeSingle();

    return profile;
  }

  static Future<Map<String, dynamic>?> createUserProfile({
    required String fullName,
    required String country,
    required String city,
    required String sector,
  }) async {
    final user = _client.auth.currentUser;
    if (user == null) {
      throw Exception('No hay usuario autenticado');
    }

    return await createUserProfileWithUserId(
      userId: user.id,
      fullName: fullName,
      country: country,
      city: city,
      sector: sector,
    );
  }

  static Future<Map<String, dynamic>?> createChurchProfilePlaceholder({
    required String fullName,
    required String country,
    required String city,
    required String sector,
  }) async {
    final user = _client.auth.currentUser;
    if (user == null) {
      throw Exception('No hay usuario autenticado');
    }

    return await createChurchProfilePlaceholderWithUserId(
      userId: user.id,
      fullName: fullName,
      country: country,
      city: city,
      sector: sector,
    );
  }
}