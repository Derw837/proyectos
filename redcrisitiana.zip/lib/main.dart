import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:red_cristiana/app/app.dart';
import 'package:red_cristiana/firebase_options.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
  } catch (_) {}
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
  } catch (e) {
    debugPrint('Error Firebase.initializeApp: $e');
  }

  try {
    FirebaseMessaging.onBackgroundMessage(
      _firebaseMessagingBackgroundHandler,
    );
  } catch (e) {
    debugPrint('Error FirebaseMessaging.onBackgroundMessage: $e');
  }

  try {
    await JustAudioBackground.init(
      androidNotificationChannelId: 'com.redcristiana.radio.channel.audio',
      androidNotificationChannelName: 'Radio Red Cristiana',
      androidNotificationOngoing: true,
    );
  } catch (e) {
    debugPrint('Error JustAudioBackground.init: $e');
  }

  try {
    await Supabase.initialize(
      url: 'https://cqzgoszqladiiluobaxn.supabase.co',
      anonKey: 'sb_publishable_9zuT2ensbTQ3H_lGqLBkCg_VVeWBm3t',
    );
  } catch (e) {
    debugPrint('Error Supabase.initialize: $e');
  }

  runApp(const RedCristianaApp());
}